import base64
import os

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
assets_dir = os.path.join(base_dir, "assets")
web_html_path = os.path.join(base_dir, "web", "index.html")
web_portal_hpp_path = os.path.join(base_dir, "include", "web_portal_html.hpp")

def get_b64_png(name):
    path = os.path.join(assets_dir, name)
    with open(path, "rb") as f:
        data = f.read()
    return f"data:image/png;base64,{base64.b64encode(data).decode('ascii')}"

b64_24 = get_b64_png("logo_24.png")
b64_32 = get_b64_png("logo_32.png")
b64_64 = get_b64_png("logo_64.png")
b64_128 = get_b64_png("logo_128.png")
b64_256 = get_b64_png("logo_256.png")

with open(web_html_path, "r", encoding="utf-8") as f:
    html = f.read()

# 1. Update <head> favicons
favicon_tags = f"""    <!-- RavenMining Multi-Resolution Favicons -->
    <link rel="icon" type="image/png" sizes="32x32" href="{b64_32}">
    <link rel="icon" type="image/png" sizes="64x64" href="{b64_64}">
    <link rel="icon" type="image/png" sizes="256x256" href="{b64_256}">
    <link rel="apple-touch-icon" sizes="128x128" href="{b64_128}">"""

# Inject favicon tags right after <title>...</title>
if '<title>FGP KAWPOW Mining Server Dashboard</title>' in html:
    html = html.replace(
        '<title>FGP KAWPOW Mining Server Dashboard</title>',
        f'<title>FGP KAWPOW Mining Server Dashboard</title>\n{favicon_tags}'
    )
elif '<!-- RavenMining Multi-Resolution Favicons -->' in html:
    # Already present or update
    pass

# 2. Update CSS for .brand-icon and add .brand-logo-img
old_brand_icon_css = """.brand-icon {
            width: 38px;
            height: 38px;
            border-radius: 10px;
            background: linear-gradient(135deg, #06b6d4, #8b5cf6);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0 16px var(--cyan-glow);
        }

        .brand-icon svg {
            width: 22px;
            height: 22px;
            fill: #ffffff;
        }"""

new_brand_icon_css = """.brand-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: rgba(15, 23, 42, 0.85);
            border: 1px solid rgba(6, 182, 212, 0.35);
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 0 16px var(--cyan-glow);
            overflow: hidden;
            position: relative;
        }

        .brand-logo-img {
            width: 26px;
            height: 26px;
            object-fit: contain;
            filter: drop-shadow(0 0 4px rgba(6, 182, 212, 0.6));
            transition: transform 0.25s ease;
        }

        .brand-icon:hover .brand-logo-img {
            transform: scale(1.1);
        }"""

if old_brand_icon_css in html:
    html = html.replace(old_brand_icon_css, new_brand_icon_css)

# 3. Replace the SVG inside .brand-icon with the brand logo img
old_brand_html = """        <div class="brand">
            <div class="brand-icon">
                <svg viewBox="0 0 24 24">
                    <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
                </svg>
            </div>
            <div class="brand-title">"""

new_brand_html = f"""        <div class="brand">
            <div class="brand-icon">
                <img src="{b64_24}" class="brand-logo-img" alt="RavenMining Logo" width="24" height="24">
            </div>
            <div class="brand-title">"""

if old_brand_html in html:
    html = html.replace(old_brand_html, new_brand_html)

with open(web_html_path, "w", encoding="utf-8") as f:
    f.write(html)
print(f"Updated {web_html_path} successfully!")

# 4. Re-generate include/web_portal_html.hpp
with open(web_html_path, "rb") as f:
    raw_bytes = f.read()

hex_lines = []
for i in range(0, len(raw_bytes), 16):
    chunk = raw_bytes[i:i+16]
    hex_str = ", ".join(f"0x{b:02x}" for b in chunk)
    hex_lines.append(f"    {hex_str},")

hpp_content = f"""#pragma once
#include <string>

namespace kawpow {{

inline const unsigned char embedded_html_data[] = {{
{chr(10).join(hex_lines)}
}};

inline std::string get_embedded_web_html() {{
    return std::string(reinterpret_cast<const char*>(embedded_html_data), sizeof(embedded_html_data));
}}

}} // namespace kawpow
"""

with open(web_portal_hpp_path, "w", encoding="utf-8") as f:
    f.write(hpp_content)

print(f"Regenerated {web_portal_hpp_path} successfully ({len(raw_bytes)} bytes embedded)!")
