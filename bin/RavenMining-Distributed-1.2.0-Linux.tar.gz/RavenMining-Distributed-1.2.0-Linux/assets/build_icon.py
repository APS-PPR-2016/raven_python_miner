from PIL import Image
import os

assets_dir = os.path.dirname(os.path.abspath(__file__))
logo_256_path = os.path.join(assets_dir, "logo_256.png")
ico_path = os.path.join(assets_dir, "app_icon.ico")

img = Image.open(logo_256_path).convert("RGBA")
# Save standard multi-resolution Windows ICO containing all requested dimensions:
sizes = [(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (24, 24), (16, 16)]
img.save(ico_path, format="ICO", sizes=sizes)

ico = Image.open(ico_path)
print(f"Generated {ico_path} ({os.path.getsize(ico_path)} bytes)")
print(f"Frames in ICO: {ico.info.get('sizes')}")
